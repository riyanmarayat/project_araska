# AksaraJawa > 2025-05-06 3:11pm
https://universe.roboflow.com/marayat-team/aksarajawa-6p691

Provided by a Roboflow user
License: CC BY 4.0

